from flask import Flask, request, jsonify, send_file, render_template
import requests
from io import BytesIO
import os

# مسیر کامل پروژه
BASE_DIR = "/storage/emulated/0/chatbot"

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "templates")
)

# کلید GPT
API_KEY = "sk-Mw8yr7VOiiiRLhBCgaQZ16yJeYr3UawY9PlJUAfdflO9fRAE"
BASE_URL = "https://api.gapgpt.app/v1"

# کلید VoiceRSS
TTS_API_KEY = "bb4a0602f02d4dc4ae63fceb048331b7"

@app.route("/")
def index():
    return render_template("chat.html")

@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json()
    message = data.get("message", "")

    try:
        response = requests.post(
            f"{BASE_URL}/chat/completions",
            headers={"Authorization": f"Bearer {API_KEY}"},
            json={
                "model": "gpt-4o",
                "messages": [{"role": "user", "content": message}],
            }
        )
        reply = response.json()["choices"][0]["message"]["content"]
        return jsonify({"reply": reply})
    except Exception as e:
        return jsonify({"reply": f"❌ خطا: {str(e)}"})

@app.route("/speak")
def speak():
    text = request.args.get("text", "")
    if not text:
        return "Text is required", 400

    params = {
        "key": TTS_API_KEY,
        "hl": "fa-ir",
        "src": text,
        "c": "MP3",
        "f": "44khz_16bit_stereo"
    }

    try:
        res = requests.get("https://api.voicerss.org/", params=params)

        # بررسی پاسخ VoiceRSS
        if res.status_code != 200:
            return f"<b>HTTP Error {res.status_code}</b><br><br>{res.text}", 500

        if res.content.startswith(b'ERROR'):
            return f"<b>VoiceRSS Error:</b> {res.content.decode()}", 500

        return send_file(BytesIO(res.content), download_name="voice.mp3", mimetype="audio/mpeg")

    except Exception as e:
        return f"<b>Server Exception:</b> {str(e)}", 500

if __name__ == "__main__":
    os.chdir(BASE_DIR)
    app.run(host="0.0.0.0", port=5000)
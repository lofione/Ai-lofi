from flask import Flask, request, jsonify, send_file
import requests
from io import BytesIO

app = Flask(__name__)

# 🔐 کلید GPT شما
API_KEY = "sk-Mw8yr7VOiiiRLhBCgaQZ16yJeYr3UawY9PlJUAfdflO9fRAE"
# 🌐 سرور gapgpt
BASE_URL = "https://api.gapgpt.app/v1"

# 🎙️ وب‌سرویس تبدیل متن به صدا
TTS_URL = "https://haji-api.ir/text-voice/"
LICENSE = "URb6s045PAD292451898105140403akjl"

@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json()
    message = data.get("message", "")
    
    try:
        response = requests.post(
            f"{BASE_URL}/chat/completions",
            headers={"Authorization": f"Bearer {API_KEY}"},
            json={
                "model": "gpt-4o",
                "messages": [{"role": "user", "content": message}],
            }
        )
        reply = response.json()["choices"][0]["message"]["content"]
        return jsonify({"reply": reply})
    except Exception as e:
        return jsonify({"reply": "خطا در ارتباط با مدل هوش مصنوعی!"})

@app.route("/speak")
def speak():
    text = request.args.get("text", "")
    if not text:
        return "Text missing", 400

    params = {
        "text": text,
        "style": "Friendly",
        "voice": "nova",
        "license": LICENSE,
        "prompt": ""
    }

    r = requests.get(TTS_URL, params=params)
    if r.status_code != 200:
        return "خطا در دریافت صدا", 500

    return send_file(BytesIO(r.content), download_name="voice.mp3", mimetype="audio/mpeg")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=7860)